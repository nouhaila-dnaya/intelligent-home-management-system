 #include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <DHT.h>
#include <Servo.h>

// --- CONFIGURATION DE L'ÉCRAN OLED ---
#define LARGEUR_ECRAN 128 // Largeur de l'écran OLED, en pixels
#define HAUTEUR_ECRAN 32  // Hauteur de l'écran OLED, en pixels
// Le pin -1 indique que l'écran ne partage pas de broche RESET avec l'Arduino
Adafruit_SSD1306 display(LARGEUR_ECRAN, HAUTEUR_ECRAN, &Wire, -1);

// --- BROCHES ARDUINO ---
#define PIN_PIR 13
#define PIN_LED_BLEUE 12
#define PIN_SERVO 9       // CORRIGÉ : branché sur la broche 9 selon votre schéma Proteus
#define PIN_BUZZER1 10
#define PIN_LED_ROUGE 8
#define PIN_BUZZER2 6
#define PIN_TRIG 2
#define PIN_ECHO 3
#define PIN_DHT A3
#define DHTTYPE DHT11     // CORRIGÉ : Changé de DHT22 à DHT11 pour correspondre au composant Proteus

DHT dht(PIN_DHT, DHTTYPE);
Servo monServo;

void setup() {
  pinMode(PIN_PIR, INPUT);
  pinMode(PIN_LED_BLEUE, OUTPUT);
  pinMode(PIN_LED_ROUGE, OUTPUT);
  pinMode(PIN_BUZZER1, OUTPUT);
  pinMode(PIN_BUZZER2, OUTPUT);
  pinMode(PIN_TRIG, OUTPUT);
  pinMode(PIN_ECHO, INPUT);

  monServo.attach(PIN_SERVO);
  monServo.write(0);
  
  dht.begin();

  // Initialisation de l'écran OLED à l'adresse I2C standard (0x3C)
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) { 
    for(;;); // Bloque le programme si l'écran n'est pas détecté par Proteus
  }
  
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 10);
  display.println("Systeme Initialise");
  display.display();
  delay(1000);
}

void loop() {
  // --- MESURES ---
  float h = dht.readHumidity();
  float t = dht.readTemperature();

  // Mesure de distance par ultrason
  digitalWrite(PIN_TRIG, LOW);
  delayMicroseconds(2);
  digitalWrite(PIN_TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(PIN_TRIG, LOW);
  long duree = pulseIn(PIN_ECHO, HIGH);
  float distance = (duree * 0.034) / 2;

  // Lecture du capteur de présence
  int mouvement = digitalRead(PIN_PIR);

  // --- AFFICHAGE ÉCRAN OLED ---
  display.clearDisplay();  // Efface l'écran pour rafraîchir les pixels
  display.setCursor(0, 0); // Positionne le curseur en haut à gauche (Ligne 1)

  // Vérification de la communication avec le DHT11
  if (isnan(h) || isnan(t)) {
    display.println("Erreur Capteur DHT");
  } else {
    // Affichage de la Température et de l'Humidité
    display.print("T: ");
    display.print(t, 1);
    display.print("C  H: ");
    display.print(h, 0);
    display.println("%");
  }

  // Positionne le curseur sur la ligne suivante (Ligne 2)
  display.setCursor(0, 16); 
  display.print("Dist: ");
  display.print(distance, 1);
  display.print("cm ");
  
  // Affiche un indicateur visuel si un mouvement est détecté
  if (mouvement == HIGH) {
    display.print("[MOV]");
  }

  display.display(); // Pousse les changements sur l'affichage réel

  // --- LOGIQUE DE CONTRÔLE DES COMPOSANTS ---

  // 1. Gestion des LEDS (Mouvement)
  if (mouvement == HIGH) {
    digitalWrite(PIN_LED_ROUGE, HIGH);
    digitalWrite(PIN_LED_BLEUE, LOW);
  } else {
    digitalWrite(PIN_LED_ROUGE, LOW);
    digitalWrite(PIN_LED_BLEUE, HIGH);
  }

  // 2. Gestion du SERVOMOTEUR (Mouvement)
  if (mouvement == HIGH) {
    monServo.write(90);  // Tourne à 90 degrés si mouvement
  } else {
    monServo.write(0);   // Revient à 0 degré si aucun mouvement
  }

  // 3. Gestion du BUZZER 1 (Alerte Mouvement)
  if (mouvement == HIGH) {
    tone(PIN_BUZZER1, 1000); // Émet un son à 1000 Hz
  } else {
    noTone(PIN_BUZZER1);     // Silence
  }

  // 4. Gestion du BUZZER 2 (Alerte Proximité / Distance)
  if (distance > 0 && distance < 15) { 
    tone(PIN_BUZZER2, 1800); // Émet un son aigu si un objet est à moins de 15 cm
  } else {
    noTone(PIN_BUZZER2);     // Silence
  }

  // 5. Sécurité Température Haute (Optionnel)
  if (t > 30.0) {
    // Vous pouvez ajouter une action ici si la température dépasse 30°C
  }

  delay(200); // Petite pause pour stabiliser la simulation Proteus
}